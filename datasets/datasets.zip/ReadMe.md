4 csv filesto create tables in SQL.
